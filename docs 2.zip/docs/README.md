# My blog
Started my blog.
